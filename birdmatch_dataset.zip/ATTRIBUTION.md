# Attribution and licenses

All recordings in this dataset come from Xeno-canto (https://xeno-canto.org).
Each recording remains the property of its recordist and is distributed under
the Creative Commons license listed for it in `metadata.csv` (columns
`recordist`, `license`, `url`). The MFCC feature files are derived from those
recordings and carry the same license terms.

Use is limited to this course project. If you redistribute any part of this
dataset or the audio, keep this file and `metadata.csv` with it, and follow
the license of each individual recording (many are non-commercial and
share-alike).
